#
# release date of tkextlib
#
module Tk
  Tkextlib_RELEASE_DATE = '2010-02-01'.freeze
end
