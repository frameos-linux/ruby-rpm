#!/usr/bin/env ruby
require 'tk'
require 'tkextlib/iwidgets'

Tk::Iwidgets::Canvasprintdialog.new.activate

Tk.mainloop

